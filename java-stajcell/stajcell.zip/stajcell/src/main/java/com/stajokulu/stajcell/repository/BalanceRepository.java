package com.stajokulu.stajcell.repository;

import com.stajokulu.stajcell.model.BalanceUnit;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BalanceRepository extends JpaRepository<BalanceUnit, Long> {

}
