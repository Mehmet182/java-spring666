package com.stajokulu.stajcell.controller;

import com.stajokulu.stajcell.service.BalanceService;
import com.stajokulu.stajcell.model.BalanceUnit;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/balance")
@RequiredArgsConstructor
public class BalanceController {

    private final BalanceService balanceService;


}
