package com.stajokulu.stajcell.service;

import com.stajokulu.stajcell.repository.BalanceRepository;
import com.stajokulu.stajcell.model.BalanceUnit;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class BalanceService {

    private final BalanceRepository balanceRepository;

}
